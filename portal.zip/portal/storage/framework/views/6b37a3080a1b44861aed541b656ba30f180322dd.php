<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12 bg-gray-apple shadow-sm p-3 mb-5 rounded">
            <div class="row">
                <div class="col-9">
                    <h2 class="font-weight-bold">Matrículas do(a) Aluno(a) <?php echo e($aluno->name); ?>:</h2>
                </div>
                <div class="col-3">
                    <a class="btn btn-secondary w-100" href="<?php echo e(route('admin.student.index')); ?>">Voltar</a>
                </div>
            </div>

            <?php if(session()->get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session()->get('message')); ?> <br>
                </div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            * <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <a class="btn btn-primary" href="<?php echo e(route('admin.matricula.create', ['student' => $aluno->id])); ?>">Cadastrar
                nova
                matrícula</a>

            <div class="row">
                <div class="col-md-12 bg-gray-apple p-3 mb-5 rounded">
                    <div class="row">
                        <?php $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <img src="<?php echo e(asset('storage/cover/' . $matricula->curso()->first()->cover)); ?>"
                                            alt="<?php echo e($matricula->curso()->first()->name); ?>"
                                            title="<?php echo e($matricula->curso()->first()->name); ?>" class="w-100">
                                    </div>
                                    <div class="col-md-8">
                                        <p class="w-100 shadow-sm m-1 p-3 bg-gray-100 rounded">
                                            <b>Nome:</b><br><?php echo e($matricula->curso()->first()->name); ?><br>
                                            <b>Início:</b>
                                            <?php echo e(date('d/m/Y', strtotime($matricula->curso()->first()->start_date))); ?><br>
                                            <b>Término:</b>
                                            <?php echo e(date('d/m/Y', strtotime($matricula->curso()->first()->end_date))); ?><br>
                                        </p>
                                    </div>
                                    <div class="col-md-4 align-self-center">
                                        <form
                                            onsubmit="return confirm('Tem certeza que deseja remover o(a) aluno(a) do curso?');"
                                            title="remover o(a) aluno(a) do curso"
                                            action="<?php echo e(route('admin.matricula.destroy', ['matricula' => $matricula->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger w-100 mt-1 mb-1 deleteCategory">
                                                <i class="far fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrativo.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/administrativo/aluno/show.blade.php ENDPATH**/ ?>