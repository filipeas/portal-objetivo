<?php $__env->startSection('content'); ?>

    <?php if(session()->get('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session()->get('message')); ?> <br>
        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    * <?php echo e($error); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    
    <div class="row">
        <div class="col-md-12 bg-gray-apple pt-3 mb-5 rounded">
            <h3>Meus Cursos</h3>
            <a class="btn btn-primary" href="<?php echo e(route('student.curso.index')); ?>">Ver mais</a>
            <div class="row">
                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="<?php echo e(asset('storage/cover/' . $matricula->curso()->first()->cover)); ?>" alt="<?php echo e($matricula->curso()->first()->name); ?>"
                                    title="<?php echo e($matricula->curso()->first()->name); ?>" class="w-100">
                            </div>
                            <div class="col-md-8">
                                <p class="w-100 shadow-sm m-1 p-3 bg-gray-100 rounded">
                                    <b>Nome:</b><br><?php echo e($matricula->curso()->first()->name); ?><br>
                                    <b>Início:</b> <?php echo e(date('d/m/Y', strtotime($matricula->curso()->first()->start_date))); ?><br>
                                    <b>Término:</b> <?php echo e(date('d/m/Y', strtotime($matricula->curso()->first()->end_date))); ?><br>
                                </p>
                            </div>
                            <div class="col-md-4 align-self-center">
                                <a class="btn btn-primary w-100 mt-1 mb-1" title="Visualizar Curso"
                                    href="<?php echo e(route('student.curso.show', ['slug_curso' => $matricula->curso()->first()->slug])); ?>">
                                    <i class="far fa-eye"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('aluno.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/aluno/home.blade.php ENDPATH**/ ?>