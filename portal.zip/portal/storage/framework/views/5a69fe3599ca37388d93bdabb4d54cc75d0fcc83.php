<?php $__env->startSection('content'); ?>

    <?php if(session()->get('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session()->get('message')); ?> <br>
        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    * <?php echo e($error); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12 bg-gray-apple pt-3 mb-5 rounded">
            <h3>Materiais do curso <b><?php echo e($curso->name); ?></b></h3>
            <div class="row">

                <table class="table table-hover table-dark m-1 text-center">
                    <thead>
                        <tr>
                            <th scope="col">Material</th>
                            <th scope="col"><i class="far fa-eye"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($material->pdf != null ? 'PDF, ' : ''); ?>

                                    <?php echo e($material->doc != null ? 'DOC, ' : ''); ?>

                                    <?php echo e($material->link_video != null ? 'Vídeo' : ''); ?></th>
                                <td>
                                    <a class="btn btn-primary w-100 mt-1 mb-1" title="Visualizar Material"
                                        href="<?php echo e(route('student.material.show', ['material' => $material->id])); ?>">
                                        <i class="far fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('aluno.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/aluno/curso/show.blade.php ENDPATH**/ ?>