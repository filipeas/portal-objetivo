<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env('APP_NAME')); ?> - Painel Administrativo</title>

    <link rel="stylesheet" href="<?php echo e(asset('site/style.css')); ?>">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="<?php echo e(asset('site/fontawesome.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('site/croppie.css')); ?>">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <?php $__env->startSection('sidebar'); ?>
        <!-- header -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03"
                aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(route('admin.home')); ?>">Início</a>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.curso.index')); ?>" title="Cursos do sistema">Cursos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.student.index')); ?>" title="Alunos do sistema">Alunos</a>
                    </li>
                </ul>

                <div class="text-center">
                    <a class="btn text-gray mr-sm-2" title="Editar perfil" alt="Editar perfil"
                        href="<?php echo e(route('admin.config.edit', ['administrador' => Auth::user()->id])); ?>">
                        Olá, <?php echo e(Auth::user()->name); ?>

                    </a>
                    <div class="btn-group">
                        <button type="button" class="btn btn-gray dropdown-toggle" data-toggle="dropdown"
                            title="Pedidos da loja" aria-haspopup="true" aria-expanded="false">
                            <i class="far fa-2x fa-user-circle"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item"
                                href="<?php echo e(route('admin.config.edit', ['administrador' => Auth::user()->id])); ?>">Editar
                                perfil</a>
                            
                            <a class="dropdown-item" href="<?php echo e(route('logout.do')); ?>">Sair</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <!-- end header -->
    <?php echo $__env->yieldSection(); ?>

    <!-- content -->
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- end content -->

    <!-- footer -->
    <!-- end footer -->

    <!-- include scripts -->
    <script src="<?php echo e(asset('site/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('site/jquery-form.js')); ?>"></script>
    <script src="<?php echo e(asset('site/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('site/fontawesome.js')); ?>"></script>
    <script src="<?php echo e(asset('site/jquery-mask.js')); ?>"></script>
    <script src="<?php echo e(asset('site/croppie.js')); ?>"></script>
    

    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $uploadCrop = $('#upload-demo').croppie({
            enableExif: true,
            viewport: {
                width: 400,
                height: 300,
            },
            boundary: {
                width: 400,
                height: 400
            },
        });

        $('#upload').on('change', function() {
            var reader = new FileReader();
            reader.onload = function(e) {
                $uploadCrop.croppie('bind', {
                    url: e.target.result
                }).then(function() {
                    console.log('jQuery bind complete');
                });
            }
            reader.readAsDataURL(this.files[0]);
        });

        $('.upload-result').on('click', function(ev) {
            $uploadCrop.croppie('result', {
                type: 'canvas',
                size: 'viewport'
            }).then(function(resp) {
                $.ajax({
                    url: "/image-crop",
                    type: "POST",
                    data: {
                        "image": resp
                    },
                    success: function(data) {
                        $('#cover').val(data.image);
                        html = '<img src="' + resp + '" />';
                        $("#upload-demo-i").html(html);
                    }
                });
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/administrativo/app.blade.php ENDPATH**/ ?>