<?php $__env->startSection('content'); ?>

    <div class="row mb-1">
        <div class="col-9">

        </div>
        <div class="col-3">
            <a class="btn btn-secondary w-100" href="<?php echo e(route('admin.curso.index')); ?>">Voltar</a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 bg-gray-apple shadow-sm p-3 mb-5 rounded">
            <h2 class="font-weight-bold">Materiais do curso <br><b><?php echo e($curso->name); ?></b>:</h2>

            <?php if(session()->get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session()->get('message')); ?> <br>
                </div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            * <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <a class="btn btn-primary"
                href="<?php echo e(route('admin.material.create', ['slug_curso' => $curso->slug])); ?>">Cadastrar novo material</a>

            <table class="table table-hover table-dark m-1 text-center">
                <thead>
                    <tr>
                        <th scope="col">Material</th>
                        <th scope="col"><i class="far fa-eye"></i></th>
                        <th scope="col"><i class="fas fa-external-link-alt"></i></th>
                        <th scope="col"><i class="far fa-trash-alt"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($material->pdf != null ? 'PDF, ' : ''); ?>

                                <?php echo e($material->doc != null ? 'DOC, ' : ''); ?>

                                <?php echo e($material->link_video != null ? 'Vídeo' : ''); ?></th>
                            <td>
                                <a class="btn btn-primary w-100 mt-1 mb-1"
                                    href="<?php echo e(route('admin.material.show', ['material' => $material->id])); ?>"><i
                                        class="far fa-eye"></i></a>
                            </td>
                            <td>
                                <a class="btn btn-success w-100 mt-1 mb-1"
                                    href="<?php echo e(route('admin.material.edit', ['material' => $material->id])); ?>"><i
                                        class="fas fa-external-link-alt"></i></a>
                            </td>
                            <td>
                                <form onsubmit="return confirm('Tem certeza que deseja excluir esse material?');"
                                    action="<?php echo e(route('admin.material.destroy', ['material' => $material->id])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger w-100 mt-1 mb-1 deleteCategory">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>


        <div class="col-md-6 bg-gray-apple shadow-sm p-3 mb-5 rounded">
            <h2 class="font-weight-bold">Matrículas do curso <br><b><?php echo e($curso->name); ?></b>:</h2>

            <?php if(session()->get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session()->get('message')); ?> <br>
                </div>
            <?php endif; ?>

            <a class="btn btn-primary" href="<?php echo e(route('admin.student.index')); ?>">Cadastrar matrícula</a>

            <table class="table table-hover table-dark m-1 text-center">
                <thead>
                    <tr>
                        <th scope="col">Aluno</th>
                        <th scope="col"><i class="far fa-eye"></i></th>
                        <th scope="col"><i class="far fa-trash-alt"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <?php echo e($matricula->aluno()->first()->name . ' ' . $matricula->aluno()->first()->lastname); ?>

                            </th>
                            <td>
                                <a class="btn btn-primary w-100 mt-1 mb-1"
                                    href="<?php echo e(route('admin.student.show', ['student' => $matricula->aluno()->first()->id])); ?>"><i
                                        class="far fa-eye"></i></a>
                            </td>
                            <td>
                                <form onsubmit="return confirm('Tem certeza que deseja remover o(a) aluno(a) do curso?');"
                                    title="remover o(a) aluno(a) do curso"
                                    action="<?php echo e(route('admin.matricula.destroy', ['matricula' => $matricula->id])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger w-100 mt-1 mb-1 deleteCategory">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrativo.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/administrativo/curso/show.blade.php ENDPATH**/ ?>