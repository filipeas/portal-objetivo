<?php $__env->startSection('content'); ?>

    <?php if(session()->get('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session()->get('message')); ?> <br>
        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    * <?php echo e($error); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    
    <div class="row">
        <div class="col-md-12 bg-gray-apple pt-3 mb-5 rounded">
            <h3>Cursos recentes</h3>
            <a class="btn btn-primary mb-2" href="<?php echo e(route('admin.curso.index')); ?>">Ver mais cursos</a>
            <div class="row">
                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="<?php echo e(asset('storage/cover/' . $curso->cover)); ?>" alt="<?php echo e($curso->name); ?>"
                                    title="<?php echo e($curso->name); ?>" class="w-100">
                            </div>
                            <div class="col-md-8">
                                <p class="w-100 shadow-sm m-1 p-3 bg-gray-100 rounded">
                                    <b>Nome:</b><br><?php echo e($curso->name); ?><br>
                                    <b>Início:</b> <?php echo e(date('d/m/Y', strtotime($curso->start_date))); ?><br>
                                    <b>Término:</b> <?php echo e(date('d/m/Y', strtotime($curso->end_date))); ?><br>
                                </p>
                            </div>
                            <div class="col-md-4 align-self-center">
                                <a class="btn btn-primary w-100 mt-1 mb-1"
                                    href="<?php echo e(route('admin.curso.show', ['slug_curso' => $curso->slug])); ?>"><i
                                        class="far fa-eye"></i></a>
                                <a class="btn btn-success w-100 mt-1 mb-1"
                                    href="<?php echo e(route('admin.curso.edit', ['slug_curso' => $curso->slug])); ?>"><i
                                        class="fas fa-external-link-alt"></i></a>
                                <form onsubmit="return confirm('Tem certeza que deseja excluir esse curso?');"
                                    action="<?php echo e(route('admin.curso.destroy', ['slug_curso' => $curso->slug])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger w-100 mt-1 mb-1 deleteCategory">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-12 bg-gray-apple p-3 mb-5 rounded">
            <h3>Matrículas recentes</h3>
            <a class="btn btn-primary mb-2" href="<?php echo e(route('admin.student.index')); ?>">Ver mais alunos</a>
            <table class="table table-hover table-dark m-1 text-center">
                <thead>
                    <tr>
                        <th scope="col">Aluno</th>
                        <th scope="col">Curso</th>
                        <th scope="col">Matriculado em</th>
                        <th scope="col"><i class="far fa-eye"></i></th>
                        <th scope="col"><i class="far fa-trash-alt"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <?php echo e($matricula->aluno()->first()->name . ' ' . $matricula->aluno()->first()->lastname); ?>

                            </th>
                            <th scope="row">
                                <?php echo e($matricula->curso()->first()->name); ?>

                            </th>
                            <th scope="row">
                                <?php echo e(date('d/m/Y', strtotime($matricula->created_at))); ?>

                            </th>
                            <td>
                                <a class="btn btn-primary w-100 mt-1 mb-1"
                                    href="<?php echo e(route('admin.student.show', ['student' => $matricula->aluno()->first()->id])); ?>"><i
                                        class="far fa-eye"></i></a>
                            </td>
                            <td>
                                <form onsubmit="return confirm('Tem certeza que deseja remover o(a) aluno(a) do curso?');"
                                    title="remover o(a) aluno(a) do curso"
                                    action="<?php echo e(route('admin.matricula.destroy', ['matricula' => $matricula->id])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger w-100 mt-1 mb-1 deleteCategory">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrativo.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/administrativo/home.blade.php ENDPATH**/ ?>