<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12 bg-gray-apple shadow-sm p-3 mb-5 rounded">
            <h2 class="font-weight-bold">Todos os Alunos:</h2>

            <?php if(session()->get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session()->get('message')); ?> <br>
                </div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            * <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <a class="btn btn-primary" href="<?php echo e(route('admin.student.create')); ?>">Cadastrar novo aluno</a>
            <br>
            <b class="m-2">Para cadastrar uma matrícula de um curso a um aluno, selecione o aluno desejado.</b>

            <div class="row">
                <div class="col-md-12 bg-gray-apple p-3 mb-5 rounded">
                    <div class="row">

                        <table class="table table-hover table-dark m-1 text-center">
                            <thead>
                                <tr>
                                    <th scope="col">Nome Completo</th>
                                    <th scope="col">Email</th>
                                    <th scope="col"><i class="far fa-eye"></i></th>
                                    <th scope="col"><i class="fas fa-external-link-alt"></i></th>
                                    <th scope="col"><i class="far fa-trash-alt"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($aluno->name . ' ' . $aluno->lastname); ?></th>
                                        <th scope="row"><?php echo e($aluno->email); ?></th>
                                        <td>
                                            <a class="btn btn-primary w-100 mt-1 mb-1"
                                                href="<?php echo e(route('admin.student.show', ['student' => $aluno->id])); ?>"><i
                                                    class="far fa-eye"></i></a>
                                        </td>
                                        <td>
                                            <a class="btn btn-success w-100 mt-1 mb-1"
                                                href="<?php echo e(route('admin.student.edit', ['student' => $aluno->id])); ?>"><i
                                                    class="fas fa-external-link-alt"></i></a>
                                        </td>
                                        <td>
                                            <form onsubmit="return confirm('Tem certeza que deseja excluir esse aluno?');"
                                                action="<?php echo e(route('admin.student.destroy', ['student' => $aluno->id])); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger w-100 mt-1 mb-1">
                                                    <i class="far fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrativo.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/administrativo/aluno/index.blade.php ENDPATH**/ ?>