<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-9">
            <h2 class="font-weight-bold">Editar Dados do Aluno <?php echo e(Auth()->user()->name); ?>:</h2>
        </div>
        <div class="col-3">
            <a class="btn btn-secondary w-100" href="<?php echo e(route('admin.student.index')); ?>">Voltar</a>
        </div>
    </div>

    <?php if(session()->get('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session()->get('message')); ?> <br>
        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    * <?php echo e($error); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="bg-gray-apple shadow-sm p-3 mb-5 rounded">
        <form action="<?php echo e(route('student.config.update', ['aluno' => Auth()->user()->id])); ?>" name="formCreateStudent"
            method="POST" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>

            <?php echo method_field('put'); ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="inputName">Nome do Aluno</label>
                        <input required name="name" type="text" class="form-control" id="inputName" placeholder="Ex: Filipe"
                            value="<?php echo e(old('name') ? old('name') : Auth()->user()->name); ?>">
                        <small class="form-text text-muted">Digite seu nome.</small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="inputLastname">Sobrenome do Aluno</label>
                        <input required name="lastname" type="text" class="form-control" id="inputLastname"
                            placeholder="Ex: Sampaio"
                            value="<?php echo e(old('lastname') ? old('lastname') : Auth()->user()->lastname); ?>">
                        <small class="form-text text-muted">Digite seu sobrenome.</small>
                    </div>
                </div>
            </div>

            <input type="submit" class="btn btn-success w-100" value="Editar">
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('aluno.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/aluno/edit.blade.php ENDPATH**/ ?>