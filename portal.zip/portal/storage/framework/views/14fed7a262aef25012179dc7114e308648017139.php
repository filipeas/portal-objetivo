<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env('APP_NAME')); ?> - Login</title>
    <!-- estilos do layout -->
    <link rel="stylesheet" href="<?php echo e(asset('site/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('site/style_login.css')); ?>">

    
</head>

<body>
    <div class="wrapper fadeInDown">
        <div id="formContent">
            <!-- Tabs Titles -->

            <!-- Icon -->
            <div class="fadeIn first p-5">
                <h4>Login</h4>
                <p>preencha seus dados para acessar o sistema.</p>
            </div>

            <?php if(session()->get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session()->get('message')); ?> <br>
                </div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            * <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form action="<?php echo e(route('login.do')); ?>" name="formLogin" method="POST">
                <?php echo csrf_field(); ?>
                <input required type="text" id="email" class="fadeIn second" name="email"
                    placeholder="E-mail do usuário">
                <input required type="password" id="password" class="fadeIn third" name="password" placeholder="Senha">
                <input type="submit" class="fadeIn fourth" value="Login">
            </form>

        </div>
    </div>
</body>

<!-- import da biblioteca do bootstrap -->

<!-- import do jquery -->

<!-- import do jquery form -->


<script src="<?php echo e(asset('site/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('site/jquery-form.js')); ?>"></script>
<script src="<?php echo e(asset('site/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('site/fontawesome.js')); ?>"></script>

<!-- import das mascaras do jquery -->
<script src="<?php echo e(asset('site/jquery-mask.js')); ?>"></script>

</html>
<?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/login.blade.php ENDPATH**/ ?>