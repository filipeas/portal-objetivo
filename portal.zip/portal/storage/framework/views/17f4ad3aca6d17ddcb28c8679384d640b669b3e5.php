<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-9">
            <h2 class="font-weight-bold">Novo Curso</h2>
        </div>
        <div class="col-3">
            <a class="btn btn-secondary w-100" href="<?php echo e(route('admin.curso.index')); ?>">Voltar</a>
        </div>
    </div>

    <?php if(session()->get('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session()->get('message')); ?> <br>
        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    * <?php echo e($error); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="bg-gray-apple shadow-sm p-3 mb-5 rounded">
        <div class="row p-5">
            <div class="col-md-12" style="padding-top:30px;">
                <strong>Selecionar imagem de capa:</strong>
                <input type="file" id="upload">
                <button class="btn btn-success upload-result">Cortar imagem</button>
            </div>

            <div class="col-md-5 text-center bg-dark">
                <div id="upload-demo" style="width:350px"></div>
            </div>

            <div class="col-md-7 text-center bg-white" style="">
                <div id="upload-demo-i"></div>
            </div>
        </div>

        <form action="<?php echo e(route('admin.curso.store')); ?>" name="formCreateCurso" method="POST"
            enctype="multipart/form-data">

            <?php echo csrf_field(); ?>

            <div class="row">
                <input required type="hidden" name="cover" id="cover">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="inputTitulo">Nome do Curso</label>
                        <input required name="name" type="text" class="form-control" id="inputCurso"
                            placeholder="Ex: Ciência da Computação" value="<?php echo e(old('name')); ?>">
                        <small class="form-text text-muted">Digite nome do curso.</small>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="inputTitulo">Data de Início do Curso</label>
                        <input required name="start_date" type="date" class="form-control" id="inputCurso"
                            placeholder="Ex: Ciência da Computação" value="<?php echo e(old('start_date')); ?>">
                        <small class="form-text text-muted">Digite a data de início do curso.</small>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="inputTitulo">Data de Término do Curso</label>
                        <input required name="end_date" type="date" class="form-control" id="inputCurso"
                            placeholder="Ex: Ciência da Computação" value="<?php echo e(old('end_date')); ?>">
                        <small class="form-text text-muted">Digite a data de término do curso.</small>
                    </div>
                </div>
            </div>

            <input type="submit" class="btn btn-primary w-100" value="Cadastrar">
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrativo.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felip\Desktop\teste objetivo teresina\protal-objetivo\portal\resources\views/administrativo/curso/create.blade.php ENDPATH**/ ?>